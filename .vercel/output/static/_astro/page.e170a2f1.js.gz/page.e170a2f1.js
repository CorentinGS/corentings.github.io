import{i}from"./index.2b677b2f.js";i();
