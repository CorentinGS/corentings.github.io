import{t as e}from"./ViewTransitions.astro_astro_type_script_index_0_lang.5f11159f.js";e.themeChange();
