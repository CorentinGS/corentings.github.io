import{t as e}from"./ViewTransitions.astro_astro_type_script_index_0_lang.56ea2483.js";e.themeChange();
