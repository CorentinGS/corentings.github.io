import{t as e}from"./ViewTransitions.astro_astro_type_script_index_0_lang.d6dac439.js";import"./index.2b677b2f.js";e.themeChange();
