import{t as e}from"./ViewTransitions.astro_astro_type_script_index_0_lang.f794c5e0.js";e.themeChange();
